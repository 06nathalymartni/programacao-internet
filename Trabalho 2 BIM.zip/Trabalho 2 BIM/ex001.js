let LadoX = document.querySelector("#LadoX")
let LadoY = document.querySelector("#LadoY")
let LadoZ = document.querySelector("#LadoZ")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function VerificacaoTiangulo() {
   let X = Number (LadoX.value);
   let Y = Number (LadoY.value);
   let Z = Number (LadoZ.value);

   if ((X < Y + Z) && (Y < X + Z) && (Z < X + Y)) {
                if (X === Y && Y === Z) {
                    resultado.textContent = "Triângulo Equilátero";
                } else if (X === Y || X === Z || Y === Z) {
                    resultado.textContent = "Triângulo Isósceles";
                } else {
                    resultado.textContent = "Triângulo Escaleno";
                }
            } else {
                resultado.textContent = "Os valores não formam um triângulo";
            }
 }
     
    btSomar.onclick = function (){
        VerificacaoTiangulo()
    }

