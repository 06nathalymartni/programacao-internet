let input1 = document.querySelector("#input1")
let input2 = document.querySelector("#input2")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function somarNumeros() {
    let ano = Number (input1.value);
    let valor = Number (input2.value);
    
    if (ano < 1990) {
        ano = 0.01; // 1%
    } else if(ano >1991){
        ano = 0.015; // 1.5%
    }
    resultado.textContent = (valor * ano);
}

btSomar.onclick = function(){
    somarNumeros()
}