let input1 = document.querySelector("#input1");
let condicaoPagamento = document.querySelector("#condicaoPagamento");
let resultado = document.querySelector("#resultado");
let btSomar = document.querySelector("#btSomar");

function calcular() {
    let preco = parseFloat(input1.value);
    let condicao = condicaoPagamento.value;
    let valorFinal;

    if (condicao === "a") {
        valorFinal = preco * 0.90;
        resultado.textContent = `Pagamento à vista em dinheiro/cheque. Total com 10% de desconto: R$ ${valorFinal.toFixed(2)}`;
    } else if (condicao === "b") {
        valorFinal = preco * 0.85;
        resultado.textContent = `Pagamento à vista no cartão. Total com 15% de desconto: R$ ${valorFinal.toFixed(2)}`;
    } else if (condicao === "c") {
        valorFinal = preco;
        resultado.textContent = `Pagamento em 2x sem juros. Total: R$ ${valorFinal.toFixed(2)} (2x de R$ ${(valorFinal / 2).toFixed(2)})`;
    } else if (condicao === "d") {
        valorFinal = preco * 1.10;
        resultado.textContent = `Pagamento em 2x com juros (10%). Total: R$ ${valorFinal.toFixed(2)} (2x de R$ ${(valorFinal / 2).toFixed(2)})`;
    } else {
        resultado.textContent = "Condição inválida.";
    }
}


    
btSomar.onclick = function (){
    calcular()
}