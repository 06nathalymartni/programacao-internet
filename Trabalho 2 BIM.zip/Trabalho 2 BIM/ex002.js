let input1 = document.querySelector("#input1")
let input2 = document.querySelector("#input2")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function Sobrepeso() {
    let peso = Number (input1.value);
    let altura = Number (input2.value);
    let imc = peso / (altura*altura);
    let classificação = "";

    if (imc < 18.5) {
        classificacao = "Abaixo do peso";
    } else if (imc >= 18.5 && imc < 25) {
        classificacao = "Peso normal";
    } else if (imc >= 25 && imc < 30) {
        classificacao = "Sobrepeso";
    } else if (imc >= 30 && imc < 35) {
        classificacao = "Obesidade grau 1";
    } else if (imc >= 35 && imc < 40) {
        classificacao = "Obesidade grau 2";
    } else {
        classificacao = "Obesidade grau 3";
    }
    resultado.textContent = `IMC: ${imc.toFixed(2)} - ${classificacao}`;
    }
    
 
btSomar.onclick = function(){
    Sobrepeso()
}







// Exibe o valor do IMC 
// Mostra a classificação:
//○ Abaixo de 18.5 → Abaixo do peso
//○ 18.5 a 24.9 → Peso normal
//○ 25 a 29.9 → Sobrepeso
//○ 30 a 34.9 → Obesidade grau 1
//○ 35 a 39.9 → Obesidade grau 2
//○ 40+ → Obesidade grau 3