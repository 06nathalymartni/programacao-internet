let input1 = document.querySelector("#input1")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function calcularCredito() {
    let saldo = parseFloat(input1.value);
    let credito = 0;


    if (saldo <= 200) {
        credito = 0;
    } else if (saldo <= 400) {
        credito = saldo * 0.2;
    } else if (saldo <= 600) {
        credito = saldo * 0.3;
    } else {
        credito = saldo * 0.4;
    }

        resultado.textContent =
        `Saldo médio: R$ ${saldo.toFixed(2)}\nCrédito concedido: R$ ${credito.toFixed(2)}`;
}

btSomar.onclick = function (){
    calcularCredito()
}