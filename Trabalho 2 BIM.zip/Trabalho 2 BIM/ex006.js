let itemPedido = document.querySelector("#itemPedido")
let input = document.querySelector("#input")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function calcularPedido() {
    let pedido = parseInt(itemPedido.value);
    let quantidade = parseInt(input.value);
    let preco = 0;
    let produto = "";


    if (pedido === 100) {
        preco = 11.00;
        produto = "Cachorro Quente";
    } else if (pedido === 101) {
        preco = 8.50;
        produto = "Bauru";
    } else if (pedido === 102) {
        preco = 8.00;
        produto = "Misto Quente";
    } else if (pedido === 103) {
        preco = 12.00;
        produto = "Hamburguer";
    } else if (pedido === 104) {
        preco = 12.50;
        produto = "Cheeseburguer";
    } else if (pedido === 105) {
        preco = 5.00;
        produto = "Refrigerante";
    }

    let total = preco * quantidade;
    resultado.textContent =
        `Pedido: ${produto}\nQuantidade: ${quantidade}\nTotal a pagar: R$ ${total.toFixed(2)}`;
}
btSomar.onclick = function(){
    calcularPedido()
}