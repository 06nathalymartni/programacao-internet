let cargoFuncionario = document.querySelector("#cargoFuncionario")
let input = document.querySelector("#input")
let btSomar = document.querySelector ("#btSomar")
let resultado = document.querySelector("#resultado")

function somarNumeros(){
    let cargo = cargoFuncionario.value;
    let salario = Number (input.value);
    let aumento = 0; 

    if(cargo === "Gerente" ){
        aumento = salario * 0.10; }
        else if (cargo === "Engenheiro"){ aumento = salario *0.20;
        } else if (cargo === "Tecnico") {
            aumento = salario * 0.30;
        } else {
            aumento = salario * 0.40
        }
        
    let novoSalario = salario + aumento;  
    
    resultado.textContent = `Novo salário com aumento: R$ ${novoSalario.toFixed(2)}`;
       
    }
        
        
    




btSomar.onclick = function(){
    somarNumeros()
}