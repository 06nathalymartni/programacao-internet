let nivel = document.querySelector("#nivel");
let horas = document.querySelector("#horas");
let resultado = document.querySelector("#resultado");
let btCalcular = document.querySelector("#btCalcular");

function calcularSalario() {
    let nivelProf = nivel.value;
    let qtdHoras = parseFloat(horas.value);
    let valorHora = 0;

    if (nivelProf === "" || isNaN(qtdHoras) || qtdHoras <= 0) {
        resultado.textContent = "Preencha todos os campos corretamente.";
        return;
    }

    if (nivelProf === "1") {
        valorHora = 12.00;
    } else if (nivelProf === "2") {
        valorHora = 17.00;
    } else if (nivelProf === "3") {
        valorHora = 25.00;
    } else {
        resultado.textContent = "Nível inválido.";
        return;
    }

    let salario = valorHora * qtdHoras * 4.5;
    resultado.textContent = `Salário mensal: R$ ${salario.toFixed(2)}`;
}

btCalcular.onclick = function(){
    calcularSalario()
}